function E = PartialEnvironmentPaper()

E = EnvironmentPaper();

%% possible map
E.pmap=E.map;


end

