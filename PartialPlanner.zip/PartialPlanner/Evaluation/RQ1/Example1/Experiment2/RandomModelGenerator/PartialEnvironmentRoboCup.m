function E = PartialEnvironmentRoboCup()

E = EnvironmentRoboCup();

%% possible map
E.pmap=E.map;

    

end

