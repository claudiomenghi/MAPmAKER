% savinge the models
save 'ModelsExperiment1.mat' ModelsExperiment1