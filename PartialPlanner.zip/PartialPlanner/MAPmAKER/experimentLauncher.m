close all;
clear;

trueEvidenceCounter=0;
falseEvicenceCounter=0;

warning('off','all')

% addpath('/Users/gsergio/Documents/MATLAB/MAPmAKER/Evaluation/Example1/Experiment1');
% addpath('/Users/gsergio/Documents/MATLAB/MAPmAKER/ReplicationPackage/Example1/Experiment1/');
% experiment1;

% addpath('/Users/gsergio/Documents/MATLAB/MAPmAKER/RunningExample/Experiment1/');
% addpath('/Users/gsergio/Documents/MATLAB/MAPmAKER/ReplicationPackage/Example2/Experiment1/');
% experiment1;
% 
addpath('/Users/gsergio/Documents/MATLAB/MAPmAKER/Evaluation/RQ1/Example1/Experiment2');
addpath('/Users/gsergio/Documents/MATLAB/MAPmAKER/Evaluation/RQ1/Example1/Algorithms/');
addpath('/Users/gsergio/Documents/MATLAB/MAPmAKER/ReplicationPackage/RQ1/Example1/Experiment2/');
experiment2;